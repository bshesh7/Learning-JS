const ChangeBtn = document.querySelector('.ChangeBtn');
const bodyBCG = document.querySelector('body');
const colors = ['red','yellow','green'];
var i = 0;
ChangeBtn.addEventListener('click', changeColor);

function  changeColor(){
    bodyBCG.style.backgroundColor = colors[i];
    i++;
    if(i>2){
        i=0;
    }
    
}